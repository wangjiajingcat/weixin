// pages/index/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    text:"",
    img01:"../../images/1-point.png",
    img02: "../../images/1-point.png",
    img03: "../../images/1-point.png",
    btnText:"摇一摇",
    btnClass:"btn",
    imgArr:[
      "../../images/1-point.png",
      "../../images/2-point.png",
      "../../images/3-point.png",
      "../../images/4-point.png",
      "../../images/5-point.png",
      "../../images/6-point.png"
    ],
    timer:null,
    isOpen:true,
    total:0
  },

  start:function(){
    var obj = this;
    if(obj.data.isOpen){
      obj.setData({
        btnText: "停止",
        btnClass: "btnClose",
        isOpen: false,
        text:""
      });
      obj.data.timer = setInterval(function () {
        let one = Math.floor(Math.random() * 6);
        let two = Math.floor(Math.random() * 6);
        let three = Math.floor(Math.random() * 6);
        obj.setData({
          img01: obj.data.imgArr[one],
          img02: obj.data.imgArr[two],
          img03: obj.data.imgArr[three],
          total:one+two+three+3
        })
      }, 50);
    }else{
      clearInterval(obj.data.timer);
      obj.setData({
        btnText: "摇一摇",
        btnClass: "btn",
        isOpen:true,
        text:"您摇到的点数是："+obj.data.total
      });
    }
  }
})