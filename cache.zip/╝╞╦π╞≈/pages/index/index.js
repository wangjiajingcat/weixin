Page({

  /**
   * 页面的初始数据
   */
  data: {
    result:0,
    isDot:true,
    onOff:true
  },
  btnclick:function(e){
    var btnval = e.target.dataset.val;
    var result = this.data.result;
    var isdot = this.data.isDot;
    if(!isNaN(btnval)){
      //是数字
      if(result == '0'){
        result = btnval;
      }else{
        result += btnval;
      }
      this.data.onOff = true;
    }else{
      //不是数字
      switch(btnval){
        case 'clear':
          result = 0;
        break;
        case 'back':
          result = result.substr(0,result.length-1);
          if(result == ''){
            result = 0;
          }
        break;
        case '.':
          if(isdot){
            result += '.';
          }
          isdot = false;
        break;
        case '+':
        case '-':
        case '*':
        case '/':
          if(this.data.onOff){
            result += btnval;
          }
          this.data.onOff = false
          isdot = true;
        break;
        case '=':
          var arr = [];
          let str = '';
          if (isNaN(result[result.length - 1])) {
            result = result.substr(0, result.length - 1);
          }
          for(var i=0;i<result.length;i++){
            let newVal = result.charAt(i);
            if(!isNaN(newVal) && newVal!='' || newVal=='.'){
              //数字拼接
              str+=newVal;
            }else{
              //符号处理
              arr.push(str);
              arr.push(newVal);
              str = '';
            }
          }
          arr.push(str);
          var result = parseFloat(arr[0]);
          for(var j=1;j<arr.length;j+=2){
            switch(arr[j]){
              case '+':
                result += parseFloat(arr[j+1]);
              break;
              case '-':
                result -= parseFloat(arr[j + 1]);
                break;
              case '*':
                result *= parseFloat(arr[j + 1]);
                break;
              case '/':
                result /= parseFloat(arr[j + 1]);
                break;
            }
          }
        break;
      }
    }
    this.setData({
      result:result,
      isDot:isdot
    })
  }
})